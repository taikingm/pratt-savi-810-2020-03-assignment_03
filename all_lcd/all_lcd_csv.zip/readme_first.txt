To view the downloadable database (pdf) file(s), you will need Adobe Acrobat Reader installed. To download the latest version of Adobe Acrobat Reader (at no cost), please copy and paste the link below into your web browser's address bar.

https://get.adobe.com/reader/

****************************************************************************************************

To view the view the downloadable database (mdb) file(s), you will need Microsoft Access Runtime installed. To download the latest version of Microsoft Access Runtime (at no cost), please copy and paste the link below into your web browser's address bar.

https://www.microsoft.com/en-us/download/details.aspx?id=50040

****************************************************************************************************

To view the downloadable Microsoft Excel Comma Separated Values (csv) files, you may use one of the following applications:

	1) Microsoft Excel
	2) Microsoft Access
	3) Microsoft Access Runtime
	4) Notepad

NOTE: Some of the information within the .csv file(s) may contain web characters (e.g., &#, #, <br>, <b>, <i>, <ul>, <li>, etc.). When using screen reading software, please be aware of these characters when going through the data.
